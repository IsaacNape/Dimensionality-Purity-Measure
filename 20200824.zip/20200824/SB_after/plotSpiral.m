clear all
close all
%%
Coin=xlsread('Coin.xlsx');
Cont=xlsread('Cont.xlsx');
%
Coin2 = diag(fliplr(Coin));
Cont2 = diag(fliplr(Cont));
fs=15
CoinNoAcci = Coin2.*(1-1./Cont2);
CoinNoAcci(CoinNoAcci<0)=0;
CoinNoAcci = CoinNoAcci./sum(CoinNoAcci);
aa=bar([-30: 30],CoinNoAcci)
alpha(aa, 0.2)
SchmidtNumber = sum(CoinNoAcci)./sum(CoinNoAcci.^2);
%%
hold on 

Spectrum = @(l, gamma) (2*gamma.^2./(1+2*gamma.^2)).^abs(2*l); 
L=[-30: 30];
Spec=Spectrum(L, sqrt((26-1)./4));
Spec=Spec./max(Spec(:));
Spec=Spec .* max(CoinNoAcci)
plot( L , Spec, 'r' , 'linewidth', 2);

hold on

Spectrum = @(l, gamma) exp(-l.^2 ./ (gamma./2).^2);
gamma=19./1.2533; % mapping between K and gamma for gaussian dist.
Spec=Spectrum(L, gamma);
Spec=Spec./max(Spec(:));
Spec=Spec .* max(CoinNoAcci);
plot( L , Spec, '-k' , 'linewidth', 2);


xlabel('$\ell$','Interpreter','latex', 'fontsize', fs );
ylabel('Coinicidence-rate','Interpreter','latex', 'fontsize', fs );
set(gca, 'fontsize', fs )

legend('Exp', 'SPDC', 'Normal Dist.')
print('Spectrum.png', '-dpng', '-r300')

save('SpecData.mat','SchmidtNumber', 'CoinNoAcci' )

%% Read data
Coin=xlsread('Coin.xlsx');

% Truncate 
Coin2 = diag(fliplr(Coin));

DD=length(Coin2);
L=(DD-1)/2 +1; 

% Largest L
Lmax=25;
 
Coin2=Coin2(L-Lmax:L+Lmax);
%bar([-13:13] ,Coin2)

Cdiag=sum(Coin2);
Ctotal= sum(sum(Coin(L-Lmax:L+Lmax, L-Lmax:L+Lmax)));

%%
Dim=length(Coin2);
Avdiag=Cdiag./Dim;
AvdiagOFF=(Ctotal - Cdiag)./(Dim^2 -Dim);
AvgCont=Avdiag/AvdiagOFF;
p =(AvgCont-1)./(AvgCont-1 + Dim)
%%