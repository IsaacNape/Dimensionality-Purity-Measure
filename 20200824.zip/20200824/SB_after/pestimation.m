%% Read data
Coin=xlsread('Coin.xlsx');

Coin_t=fliplr(Coin) ;
for i =1: length(Coin)
    for j =2: length(Coin)
        if i == j+1
            Coin_t(i, i+1) = 0;
        elseif i == j-1 & i>1  & j>1
            Coin_t(i, i-1) = 0;
        end
    end
end
Coin=fliplr(Coin_t);

% Truncate 
Coin2 = diag(fliplr(Coin));

DD=length(Coin2);
L=(DD-1)/2 +1; 

% Largest L
Lmax=11;

Coin2=Coin2(L-Lmax:L+Lmax);
bar(L-Lmax:L+Lmax ,Coin2)

Cdiag=sum(Coin2);
Ctotal= sum(sum(Coin(L-Lmax:L+Lmax, L-Lmax:L+Lmax)));

%
Dim=length(Coin2);
Avdiag=Cdiag./Dim;
AvdiagOFF=(Ctotal - Cdiag)./(Dim^2 -Dim);
AvgCont=Avdiag/AvdiagOFF
p =(AvgCont-1)./(AvgCont-1 + Dim)